const $ = (id) => document.getElementById(id);
const send = (m) => chrome.runtime.sendMessage(m);
let trialExpired = false;

function setStatus(msg, isErr) {
  const el = $("status");
  el.textContent = msg;
  el.className = isErr ? "err" : "";
}

function renderBackfillProgress(progress) {
  const isFresh = progress && Date.now() - (progress.updatedAt || 0) < 15 * 60 * 1000;
  if (!progress || !progress.active || !isFresh) {
    $("backfill").disabled = trialExpired;
    return;
  }
  const total = Number.isFinite(progress.total) ? progress.total : "?";
  $("backfill").disabled = true;
  setStatus(
    `Backing up ${progress.provider || "history"} — ${progress.processed || 0}/${total} checked\n` +
    `${progress.saved || 0} saved · ${progress.unchanged || 0} current · ${progress.failed || 0} failed`
  );
}

function ago(ts) {
  const s = Math.floor((Date.now() - ts) / 1000);
  if (s < 60) return `${s}s ago`;
  if (s < 3600) return `${Math.floor(s / 60)}m ago`;
  if (s < 86400) return `${Math.floor(s / 3600)}h ago`;
  return `${Math.floor(s / 86400)}d ago`;
}

const esc = (s) =>
  String(s).replace(/[&<>"]/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]));

function renderLog(log) {
  const el = $("log");
  if (!log.length) {
    el.innerHTML = '<div class="empty">Nothing synced yet. Open an AI chat and press Sync.</div>';
    return;
  }
  el.innerHTML = log
    .map((e) => {
      const pill = e.via ? `<span class="pill ${e.via === "dom" ? "dom" : ""}">${e.via}</span>` : "";
      if (!e.ok) {
        return `<div class="entry bad">
          <div class="entry-top"><span class="entry-title">${esc(e.title || "Sync failed")}</span></div>
          <div class="entry-meta">${esc((e.error || "").slice(0, 80))} · ${ago(e.at)}</div></div>`;
      }
      const extras = e.extras ? ` · +${e.extras} files` : "";
      return `<div class="entry">
        <div class="entry-top"><span class="entry-title">${esc(e.title || "Untitled")}</span>${pill}</div>
        <div class="entry-meta">${esc(e.source || "")} · ${e.messages ?? 0} msgs${extras} · ${ago(e.at)}</div></div>`;
    })
    .join("");
}

async function refresh() {
  const s = await send({ type: "GET_STATE" });
  if (!s) return;
  const banner = $("folder");
  if (s.folder.hasFolder) {
    banner.className = "banner";
    $("folderText").textContent = `${s.folder.name} → AI Chats / carry-backup`;
  } else {
    banner.className = "banner none";
    $("folderText").textContent = "No save folder chosen";
  }
  const memory = s.memory || { conversations: 0, topics: 0 };
  const memoryBanner = $("memory");
  if (s.memoryViewsReadyAt) {
    memoryBanner.className = "banner";
    $("memoryText").textContent =
      `Memory Home · ${memory.conversations || 0} chats · ${memory.topics || 0} topics`;
  } else {
    memoryBanner.className = "banner none";
    $("memoryText").textContent = "Memory Home will be built after setup";
  }
  const lic = s.licence || {};
  const tb = $("trial");
  trialExpired = !lic.licensed && lic.expired === true;
  if (lic.licensed) {
    tb.style.display = "none";
  } else if (lic.expired) {
    tb.style.display = "flex";
    tb.className = "banner none";
    $("trialText").textContent = "14-day trial ended — syncing is paused until you activate a licence";
  } else {
    tb.style.display = "flex";
    tb.className = "banner";
    $("trialText").textContent = `14-day trial — ${lic.daysLeft} day${lic.daysLeft === 1 ? "" : "s"} left`;
  }

  $("syncNow").disabled = trialExpired;
  $("bgSync").disabled = trialExpired;
  $("interval").disabled = trialExpired;
  $("bgSync").checked = trialExpired ? false : s.settings.backgroundSync;
  $("interval").value = String(s.settings.intervalMinutes);
  $("total").textContent = s.totalSynced;
  renderLog(s.log);
  renderBackfillProgress(s.backfillProgress);
}

const activeTab = async () => (await chrome.tabs.query({ active: true, currentWindow: true }))[0];

// The File System Access picker closes an extension popup the moment it opens (the
// popup loses focus, aborting the picker), so settings live in a normal tab. Open it
// by URL rather than openOptionsPage(), which fails if Chrome has a stale manifest.
$("pickFolder").addEventListener("click", async () => {
  const url = chrome.runtime.getURL("src/ui/options.html");
  try {
    const existing = await chrome.tabs.query({ url });
    if (existing.length) await chrome.tabs.update(existing[0].id, { active: true });
    else await chrome.tabs.create({ url });
  } catch (e) {
    await chrome.tabs.create({ url });
  }
  window.close();
});

$("syncNow").addEventListener("click", async () => {
  setStatus("Syncing…");
  const tab = await activeTab();
  const r = await send({ type: "SYNC_ACTIVE_TAB", tabId: tab.id });
  if (!r || !r.ok) {
    if (r && /No conversation found/i.test(r.error || "")) {
      setStatus("No conversation is open. Open one from the sidebar, or use Back up all for history.", true);
    } else {
      setStatus("Could not read this page: " + ((r && r.error) || "unknown"), true);
    }
  }
  else if (r.status === "unchanged") setStatus("Already up to date.");
  else if (r.status === "error") {
    if (r.error === "NO_FOLDER") setStatus("Choose a save folder first.", true);
    else if (r.error === "TRIAL_ENDED")
      setStatus("Your trial has ended. Activate a licence in Settings to keep syncing.", true);
    else setStatus("Save failed: " + r.error, true);
  }
  else {
    const warning = r.warning ? `\n${r.warning}` : "";
    const memoryWarning = r.memory && !r.memory.ok ? `\nMemory Home update failed: ${r.memory.error}` : "";
    setStatus(`Saved ${r.count} messages${r.extras ? ` + ${r.extras} files` : ""} via ${r.via}\n${r.relPath}${warning}${memoryWarning}`, !!memoryWarning);
  }
  await refresh();
});

$("backfill").addEventListener("click", async () => {
  const tab = await activeTab();
  $("backfill").disabled = true;
  setStatus("Starting history backup. Keep this popup open; progress is saved after every page.");
  try {
    // A zero limit means every ChatGPT page reported by the provider. Other
    // providers retain their existing bounded one-response implementation.
    const r = await send({ type: "BACKFILL", tabId: tab.id, limit: 0 });
    if (!r || (r.saved == null && !r.ok)) {
      if (r && r.error === "BACKFILL_ALREADY_RUNNING") {
        setStatus("A history backup is already running. Progress will appear here.", true);
      } else if (r && r.error === "TRIAL_ENDED") {
        setStatus("Your 14-day trial has ended. Activate a licence in Settings to resume syncing.", true);
      } else {
        setStatus("Backfill failed: " + ((r && r.error) || "unknown"), true);
      }
    } else {
      const failure = r.failed
        ? ` ${r.failed} failed. ${((r.failures || [])[0] || {}).title || "Open activity for details"}.`
        : "";
      setStatus(
        `Done — ${r.processed} checked: ${r.saved} saved, ${r.unchanged} already current, ` +
        `${r.projectsSaved} projects (history reported ${r.total}).${failure}`,
        r.failed > 0
      );
    }
  } finally {
    $("backfill").disabled = false;
    await refresh();
  }
});

$("diagnose").addEventListener("click", async () => {
  setStatus("Probing…");
  const tab = await activeTab();
  const r = await send({ type: "DIAGNOSE", tabId: tab.id });
  const box = $("diag");
  box.style.display = "block";

  if (!r || !r.ok) {
    box.textContent =
      "Could not reach this page.\n\nEither it is not a supported AI chat site, or the\n" +
      "extension could not attach to it.\n\n" + ((r && r.error) || "unknown error");
    setStatus("Diagnostics failed.", true);
    return;
  }
  const lines = [
    `provider  ${r.source}`,
    `folder    ${r.folder.hasFolder ? r.folder.name : "NOT SET"}`,
    "",
  ];
  for (const s of r.steps) {
    const result = s.skipped ? "SKIP" : (s.ok ? "PASS" : "FAIL");
    lines.push(`${result}  ${s.step}\n      ${s.detail}`);
  }
  box.textContent = lines.join("\n");
  setStatus(r.steps.every((s) => s.ok || s.skipped) ? "All applicable checks passed." : "Some checks failed — see below.");
});

chrome.storage.onChanged.addListener((changes, area) => {
  if (area === "local" && changes.backfillProgress) {
    renderBackfillProgress(changes.backfillProgress.newValue);
  }
});

$("bgSync").addEventListener("change", async () => {
  const r = await send({ type: "SET_SETTINGS", settings: { backgroundSync: $("bgSync").checked } });
  if (r && r.error === "TRIAL_ENDED") {
    $("bgSync").checked = false;
    setStatus("Your 14-day trial has ended. Activate a licence in Settings to resume syncing.", true);
  }
});
$("interval").addEventListener("change", async () => {
  await send({ type: "SET_SETTINGS", settings: { intervalMinutes: Number($("interval").value) } });
});

$("ver").textContent = "v" + chrome.runtime.getManifest().version;
refresh();

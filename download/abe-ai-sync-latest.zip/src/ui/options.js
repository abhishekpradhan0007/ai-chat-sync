const $ = (id) => document.getElementById(id);

async function refresh() {
  const root = await window.ChatSyncFS.getVaultRoot();
  const banner = $("status");
  if (root) {
    banner.className = "banner";
    $("statusText").textContent = `Connected — saving into “${root.name}”`;
  } else {
    banner.className = "banner none";
    $("statusText").textContent = "No folder chosen yet";
  }
  const s = await chrome.storage.local.get([
    "backgroundSync", "intervalMinutes", "saveArtifacts", "saveFiles", "saveProjects",
    "sortByCategory",
  ]);
  $("bgSync").checked = s.backgroundSync !== false;
  $("interval").value = String(s.intervalMinutes || 2);
  $("saveArtifacts").checked = s.saveArtifacts !== false;
  $("saveFiles").checked = s.saveFiles !== false;
  $("saveProjects").checked = s.saveProjects !== false;
  $("sortByCategory").checked = s.sortByCategory === true;

  const state = await chrome.runtime.sendMessage({ type: "GET_STATE" });
  const expired = Boolean(state && state.licence && !state.licence.licensed && state.licence.expired);
  $("bgSync").disabled = expired;
  $("interval").disabled = expired;
  if (expired) $("bgSync").checked = false;
  const memory = (state && state.memory) || { conversations: 0, topics: 0 };
  const memoryBanner = $("memoryStatus");
  if (state && state.memoryViewsReadyAt) {
    memoryBanner.className = "banner";
    $("memoryText").textContent =
      `Ready — ${memory.conversations || 0} conversations, ${memory.topics || 0} topic hubs`;
  } else {
    memoryBanner.className = "banner none";
    $("memoryText").textContent = "Memory Home not built yet";
  }
}

// Runs in a normal tab, so the directory picker keeps focus and can complete.
$("pick").addEventListener("click", async () => {
  try {
    await window.ChatSyncFS.pickVaultRoot();
    const memory = await chrome.runtime.sendMessage({ type: "REFRESH_MEMORY_VIEWS" });
    if (!memory || !memory.ok) {
      throw new Error(`Folder connected, but Memory Home could not be built: ${(memory && memory.error) || "unknown error"}`);
    }
    await refresh();
  } catch (e) {
    const banner = $("status");
    banner.className = "banner none";
    $("statusText").textContent =
      e && e.name === "AbortError"
        ? "Folder selection cancelled — nothing changed"
        : "Could not open the folder picker: " + ((e && e.message) || e);
  }
});

$("rebuildMemory").addEventListener("click", async () => {
  const button = $("rebuildMemory");
  button.disabled = true;
  button.textContent = "Rebuilding…";
  const result = await chrome.runtime.sendMessage({ type: "REFRESH_MEMORY_VIEWS" });
  button.disabled = false;
  button.textContent = "Rebuild Memory Home";
  const banner = $("memoryStatus");
  if (!result || !result.ok) {
    banner.className = "banner none";
    $("memoryText").textContent = `Could not rebuild: ${(result && result.error) || "unknown error"}`;
    return;
  }
  await refresh();
});

for (const [id, key] of [
  ["bgSync", "backgroundSync"],
  ["saveArtifacts", "saveArtifacts"],
  ["saveFiles", "saveFiles"],
  ["saveProjects", "saveProjects"],
  ["sortByCategory", "sortByCategory"],
]) {
  $(id).addEventListener("change", () =>
    chrome.runtime.sendMessage({ type: "SET_SETTINGS", settings: { [key]: $(id).checked } })
  );
}
$("interval").addEventListener("change", () =>
  chrome.runtime.sendMessage({
    type: "SET_SETTINGS",
    settings: { intervalMinutes: Number($("interval").value) },
  })
);

// --- licence ---------------------------------------------------------------

function plural(n, w) { return `${n} ${w}${n === 1 ? "" : "s"}`; }

async function refreshLicence() {
  const st = await chrome.runtime.sendMessage({ type: "LICENCE_STATE" });
  const banner = $("licStatus");
  const text = $("licText");

  if (st.licensed) {
    banner.className = "banner";
    text.textContent = `Licensed to ${st.email} — lifetime`;
    $("licEntry").style.display = "none";
    $("licActive").style.display = "block";
    return;
  }

  $("licEntry").style.display = "block";
  $("licActive").style.display = "none";

  if (st.expired) {
    banner.className = "banner none";
    text.textContent = "14-day trial ended — all new syncing is paused until you activate a licence";
  } else {
    banner.className = "banner";
    text.textContent = `14-day trial — ${plural(st.daysLeft, "day")} left`;
  }
}

$("activate").addEventListener("click", async () => {
  const key = $("licKey").value;
  if (!key.trim()) return;
  const btn = $("activate");
  btn.disabled = true;
  btn.textContent = "Checking…";
  const r = await chrome.runtime.sendMessage({ type: "LICENCE_ACTIVATE", key });
  btn.disabled = false;
  btn.textContent = "Activate";

  if (r && r.valid) {
    $("licKey").value = "";
  } else {
    const banner = $("licStatus");
    banner.className = "banner none";
    $("licText").textContent = (r && r.error) || "That licence key could not be verified.";
    return;
  }
  await refreshLicence();
  await refresh();
});

$("deactivate").addEventListener("click", async () => {
  await chrome.runtime.sendMessage({ type: "LICENCE_CLEAR" });
  await refreshLicence();
  await refresh();
});

$("indexVault").addEventListener("click", async () => {
  const out = $("indexStatus");
  const btn = $("indexVault");
  btn.disabled = true;
  out.textContent = "Reading the folder…";
  const r = await chrome.runtime.sendMessage({ type: "INDEX_VAULT" });
  btn.disabled = false;
  if (!r || !r.ok) {
    out.textContent = r && r.error === "NO_FOLDER"
      ? "Choose a save folder first."
      : "Could not read the folder: " + ((r && r.error) || "unknown");
    return;
  }
  out.textContent = r.added
    ? `Found ${r.scanned} note(s), added ${r.added} to Memory Home.`
    : `Found ${r.scanned} note(s) — all already indexed.`;
});

$("ver").textContent = "v" + chrome.runtime.getManifest().version;
refresh();
refreshLicence();

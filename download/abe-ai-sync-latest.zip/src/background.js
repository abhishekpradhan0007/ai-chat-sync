// Service worker: owns the sync loop. Extracts from tabs, builds markdown + hashes,
// dedupes, and hands finished files to the offscreen document for disk writes.

importScripts("lib/categorise.js", "lib/markdown.js", "lib/memory.js", "lib/licenceLS.js", "lib/licence.js");

const SUPPORTED = [
  "https://claude.ai/*",
  "https://chatgpt.com/*",
  "https://chat.openai.com/*",
  "https://grok.com/*",
  "https://gemini.google.com/*",
  "https://www.perplexity.ai/*",
];

const ALARM = "chat-sync-tick";
const BASE = ["AI Chats", "carry-backup"];

// ---------- offscreen lifecycle ----------

let creating = null;

async function ensureOffscreen() {
  const existing = await chrome.runtime.getContexts({ contextTypes: ["OFFSCREEN_DOCUMENT"] });
  if (existing.length) return;
  if (creating) return creating;
  creating = chrome.offscreen.createDocument({
    url: "src/offscreen.html",
    reasons: ["BLOBS"],
    justification:
      "Hold the user-granted File System Access handle and write conversation Markdown to the chosen folder.",
  });
  try {
    await creating;
  } finally {
    creating = null;
  }
}

async function writeFiles(files) {
  await ensureOffscreen();
  return chrome.runtime.sendMessage({ target: "offscreen", type: "OFFSCREEN_WRITE_BATCH", files });
}

async function deleteFiles(files) {
  await ensureOffscreen();
  return chrome.runtime.sendMessage({ target: "offscreen", type: "OFFSCREEN_DELETE_BATCH", files });
}

// ---------- settings + state ----------

async function getSettings() {
  const r = await chrome.storage.local.get([
    "backgroundSync",
    "intervalMinutes",
    "saveArtifacts",
    "saveFiles",
    "saveProjects",
    "sortByCategory",
    "categories",
  ]);
  return {
    sortByCategory: r.sortByCategory === true,
    categories: r.categories || null,
    backgroundSync: r.backgroundSync === true,
    intervalMinutes: r.intervalMinutes || 2,
    saveArtifacts: r.saveArtifacts !== false,
    saveFiles: r.saveFiles !== false,
    saveProjects: r.saveProjects !== false,
  };
}

async function getSynced() {
  const r = await chrome.storage.local.get(["syncedIds"]);
  return r.syncedIds || {};
}

async function getMemoryCatalog() {
  const r = await chrome.storage.local.get(["memoryCatalog", "syncedIds"]);
  const catalog = r.memoryCatalog || {};
  let changed = false;

  // v0.3.1 stored only a hash and path. Preserve those conversations in Memory
  // Home immediately, then enrich them with topics when they are next synced.
  for (const [id, synced] of Object.entries(r.syncedIds || {})) {
    if (catalog[id]) continue;
    const migrated = legacyCatalogEntry(id, synced);
    if (!migrated) continue;
    catalog[id] = migrated;
    changed = true;
  }
  if (changed) await chrome.storage.local.set({ memoryCatalog: catalog });
  return catalog;
}

function catalogEntryFor(conv, built, relPath) {
  return {
    id: conv.id,
    title: conv.title || "Untitled",
    source: conv.source || "unknown",
    relPath,
    category: built.category || "Unsorted",
    topics: built.topics || [],
    createdISO: conv.createdISO || "",
    updatedISO: conv.updatedISO || conv.createdISO || "",
    syncedAt: Date.now(),
    messageCount: (conv.messages || []).length,
    captureMethod: conv.captureMethod || "unknown",
    captureScope: conv.captureScope || (conv.captureMethod === "api" ? "full" : "visible"),
    hash: built.noteHash || built.contentHash,
  };
}

async function upsertMemoryCatalog(conv, built, relPath) {
  const catalog = await getMemoryCatalog();
  const previous = catalog[conv.id];
  const next = catalogEntryFor(conv, built, relPath);

  // Keep the catalog timestamp stable when nothing user-visible changed; otherwise
  // every background scan would rewrite Memory Home despite an identical chat.
  if (previous && previous.hash === next.hash && previous.relPath === next.relPath &&
      previous.captureMethod === next.captureMethod && previous.captureScope === next.captureScope &&
      JSON.stringify(previous.topics || []) === JSON.stringify(next.topics || [])) {
    next.syncedAt = previous.syncedAt;
  }
  const changed = !previous || JSON.stringify(previous) !== JSON.stringify(next);
  if (changed) {
    catalog[conv.id] = next;
    await chrome.storage.local.set({ memoryCatalog: catalog });
  }
  return changed;
}

async function refreshMemoryViews() {
  const catalog = await getMemoryCatalog();
  const r = await chrome.storage.local.get(["memoryHubTopics", "memoryViewHashes"]);
  const views = buildMemoryViewFiles(catalog, r.memoryHubTopics || []);
  const previousHashes = r.memoryViewHashes || {};
  const nextHashes = {};
  const changedFiles = [];

  for (const file of views.files) {
    const relPath = file.segments.concat(file.filename).join("/");
    const hash = await sha256(file.contents);
    nextHashes[relPath] = hash;
    if (previousHashes[relPath] !== hash) changedFiles.push(file);
  }

  if (changedFiles.length) {
    const resp = await writeFiles(changedFiles);
    if (!resp || !resp.ok) {
      return { ok: false, error: resp ? resp.error : "no response", ...views.stats };
    }
  }

  let removed = 0;
  if (views.deletions.length) {
    const resp = await deleteFiles(views.deletions);
    if (!resp || !resp.ok) {
      return { ok: false, error: resp ? resp.error : "no response", ...views.stats };
    }
    removed = (resp.removed || []).length;
  }

  await chrome.storage.local.set({
    memoryHubTopics: views.activeTopics,
    memoryViewHashes: nextHashes,
    memoryStats: views.stats,
    memoryViewsReadyAt: Date.now(),
  });
  return { ok: true, written: changedFiles.length, removed, ...views.stats };
}

// Two conversations can share a date+title and therefore a filename (e.g. several
// "Untitled" chats on one day). Claim filenames per conversation id; on collision,
// disambiguate with a short id suffix so no conversation is silently overwritten.
async function claimFilename(convId, filename) {
  const r = await chrome.storage.local.get(["fileOwners"]);
  const owners = r.fileOwners || {};
  const owner = owners[filename];
  if (owner && owner !== convId) {
    const dot = filename.lastIndexOf(".");
    const stem = dot > 0 ? filename.slice(0, dot) : filename;
    const ext = dot > 0 ? filename.slice(dot) : "";
    filename = `${stem} — ${String(convId).slice(0, 8)}${ext}`;
  }
  if (owners[filename] !== convId) {
    owners[filename] = convId;
    await chrome.storage.local.set({ fileOwners: owners });
  }
  return filename;
}

async function markSynced(id, hash, relPath) {
  const syncedIds = await getSynced();
  syncedIds[id] = { hash, at: Date.now(), relPath };
  await chrome.storage.local.set({ syncedIds });
}

async function pushLog(entry) {
  const r = await chrome.storage.local.get(["log"]);
  const log = r.log || [];
  log.unshift({ ...entry, at: Date.now() });
  await chrome.storage.local.set({ log: log.slice(0, 60) });
}

async function setBackfillProgress(progress) {
  const value = { ...progress, updatedAt: Date.now() };
  await chrome.storage.local.set({ backfillProgress: value });
  return value;
}

// ---------- core ----------

function validateConversation(conv) {
  if (!conv || typeof conv !== "object") throw new Error("CAPTURE_EMPTY");
  if (!conv.id || !conv.source) throw new Error("CAPTURE_MISSING_ID_OR_SOURCE");
  if (!Array.isArray(conv.messages) || !conv.messages.length) throw new Error("CAPTURE_NO_MESSAGES");

  const messages = conv.messages
    .filter((message) => message && (message.role === "user" || message.role === "assistant"))
    .map((message) => ({ role: message.role, text: String(message.text || "").trim() }))
    .filter((message) => message.text);
  if (!messages.length) throw new Error("CAPTURE_NO_READABLE_MESSAGES");

  return {
    artifacts: [],
    files: [],
    title: "Untitled",
    createdISO: new Date().toISOString(),
    updatedISO: new Date().toISOString(),
    ...conv,
    id: String(conv.id),
    source: String(conv.source),
    title: String(conv.title || "Untitled").trim() || "Untitled",
    messages,
    artifacts: Array.isArray(conv.artifacts) ? conv.artifacts : [],
    files: Array.isArray(conv.files) ? conv.files : [],
  };
}

// Which content scripts belong to which site. Mirrors manifest.content_scripts so a
// tab opened before the extension was installed/reloaded can still be reached.
const INJECT = [
  { match: /^https:\/\/claude\.ai\//, files: ["src/lib/apiClaude.js", "src/content/_wire.js", "src/parsers/claude.js"] },
  { match: /^https:\/\/(chatgpt\.com|chat\.openai\.com)\//, files: ["src/lib/apiChatgpt.js", "src/content/_wire.js", "src/parsers/chatgpt.js"] },
  { match: /^https:\/\/grok\.com\//, files: ["src/lib/apiGrok.js", "src/content/_wire.js", "src/parsers/grok.js"] },
  { match: /^https:\/\/gemini\.google\.com\//, files: ["src/content/_wire.js", "src/parsers/gemini.js"] },
  { match: /^https:\/\/www\.perplexity\.ai\//, files: ["src/content/_wire.js", "src/parsers/perplexity.js"] },
];

function sendOnce(tabId, message) {
  return new Promise((resolve) => {
    chrome.tabs.sendMessage(tabId, message, (resp) => {
      if (chrome.runtime.lastError) resolve({ ok: false, error: chrome.runtime.lastError.message });
      else resolve(resp || { ok: false, error: "No response from page." });
    });
  });
}

async function injectInto(tabId) {
  const tab = await chrome.tabs.get(tabId);
  const entry = INJECT.find((e) => e.match.test(tab.url || ""));
  if (!entry) return false;
  const files = entry.files.includes("src/parsers/gemini.js") || entry.files.includes("src/parsers/perplexity.js")
    ? ["src/lib/domToMarkdown.js", ...entry.files]
    : entry.files;
  await chrome.scripting.executeScript({ target: { tabId }, files });
  return true;
}

// Tabs that were already open when the extension was installed or reloaded have no
// content script. Inject it on demand rather than making the user reload the page.
async function ask(tabId, message) {
  const first = await sendOnce(tabId, message);
  if (first.ok) return first;
  if (!/Receiving end does not exist|Could not establish connection/i.test(first.error || "")) {
    return first;
  }

  // No content script yet (tab predates the install/reload). Attach and retry.
  let tabUrl = "";
  try {
    const tab = await chrome.tabs.get(tabId);
    tabUrl = tab.url || "";
  } catch (e) {
    return { ok: false, error: `[stage: tabs.get] ${(e && e.message) || e}` };
  }

  const entry = INJECT.find((e) => e.match.test(tabUrl));
  if (!entry) {
    return { ok: false, error: `[stage: match] Not a supported AI chat site: ${tabUrl.slice(0, 60)}` };
  }

  try {
    const files = entry.files.includes("src/parsers/gemini.js") || entry.files.includes("src/parsers/perplexity.js")
      ? ["src/lib/domToMarkdown.js", ...entry.files]
      : entry.files;
    await chrome.scripting.executeScript({ target: { tabId }, files });
  } catch (e) {
    return { ok: false, error: `[stage: inject] ${(e && e.message) || e}` };
  }

  const pong = await sendOnce(tabId, { type: "CHAT_SYNC_PING" });
  if (!pong.ok) {
    return { ok: false, error: `[stage: post-inject ping] ${pong.error}` };
  }

  const second = await sendOnce(tabId, message);
  if (!second.ok) return { ok: false, error: `[stage: retry] ${second.error}` };
  return second;
}

// Turns one conversation into every file it should produce.
async function filesForConversation(conv, settings) {
  const built = await buildMarkdown(conv, settings);
  const { markdown, contentHash } = built;
  const filename = await claimFilename(conv.id, built.filename);
  const convDir = BASE.concat(settings.sortByCategory ? [built.category] : [], conv.source);
  const files = [{ segments: convDir, filename, contents: markdown }];

  if (settings.saveArtifacts) {
    for (const a of conv.artifacts || []) {
      const f = buildArtifactFile(conv, a);
      files.push({ segments: convDir.concat("artifacts"), ...f });
    }
  }
  if (settings.saveFiles) {
    for (const file of conv.files || []) {
      const f = buildAttachmentFile(file);
      files.push({ segments: convDir.concat("files"), ...f });
    }
  }
  return {
    files,
    contentHash: built.noteHash || contentHash,
    filename,
    primaryPath: convDir.concat(filename).join("/"),
    built,
  };
}

async function syncConversation(conv, settings) {
  if (!(await Licence.canSync())) {
    return { status: "error", filename: "", error: "TRIAL_ENDED" };
  }
  conv = validateConversation(conv);
  const synced = await getSynced();
  const { files, contentHash, filename, primaryPath, built } = await filesForConversation(conv, settings);

  const prev = synced[conv.id];
  if (prev && prev.hash === contentHash && prev.relPath === primaryPath) {
    const catalogChanged = await upsertMemoryCatalog(conv, built, primaryPath);
    return { status: "unchanged", filename, relPath: primaryPath, catalogChanged };
  }

  const resp = await writeFiles(files);
  if (!resp || !resp.ok) {
    return { status: "error", filename, error: resp ? resp.error : "no response" };
  }
  await markSynced(conv.id, contentHash, resp.written[0]);
  const catalogChanged = await upsertMemoryCatalog(conv, built, resp.written[0]);
  return {
    status: "saved",
    filename,
    relPath: resp.written[0],
    count: conv.messages.length,
    extras: resp.written.length - 1,
    catalogChanged,
  };
}

async function syncProjects(projects) {
  if (!(await Licence.canSync())) {
    return {
      saved: 0,
      failures: [{ title: "Claude projects", error: "TRIAL_ENDED" }],
    };
  }
  let saved = 0;
  const failures = [];
  for (const p of projects || []) {
    if (!(await Licence.canSync())) {
      failures.push({ title: "Claude projects", error: "TRIAL_ENDED" });
      break;
    }
    try {
      const { markdown, contentHash, filename } = await buildProjectMarkdown(p);
      const synced = await getSynced();
      const key = `project:${p.id}`;
      if (synced[key] && synced[key].hash === contentHash) continue;

      const files = [{ segments: BASE.concat("claude", "projects"), filename, contents: markdown }];
      for (const d of p.docs || []) {
        files.push({
          segments: BASE.concat("claude", "projects", p.name.replace(/[\\/:*?"<>|]/g, "-")),
          filename: d.name.replace(/[\\/:*?"<>|]/g, "-"),
          contents: d.content,
        });
      }
      const resp = await writeFiles(files);
      if (!resp || !resp.ok) throw new Error(resp ? resp.error : "no response");
      await markSynced(key, contentHash, resp.written[0]);
      saved++;
    } catch (e) {
      failures.push({
        title: (p && p.name) || "Untitled Claude project",
        error: String((e && e.message) || e),
      });
    }
  }
  return { saved, failures };
}

async function syncOpenTabs(trigger) {
  if (!(await Licence.canSync())) {
    return { scanned: 0, saved: 0, failed: 0, memory: null, error: "TRIAL_ENDED" };
  }
  const settings = await getSettings();
  const tabs = await chrome.tabs.query({ url: SUPPORTED });
  let saved = 0;
  let failed = 0;
  let catalogChanged = false;

  for (const tab of tabs) {
    const resp = await ask(tab.id, { type: "CHAT_SYNC_EXTRACT" });
    if (!resp.ok) {
      failed++;
      await pushLog({ ok: false, title: tab.title || "Capture failed", error: resp.error, trigger });
      continue;
    }
    try {
      resp.conversation.captureMethod = resp.via || resp.conversation.captureMethod || "unknown";
      resp.conversation.captureScope = resp.via === "api" ? "full" : "visible";
      const result = await syncConversation(resp.conversation, settings);
      catalogChanged = catalogChanged || result.catalogChanged === true;
      if (result.status === "saved") {
        saved++;
        await pushLog({
          ok: true,
          title: resp.conversation.title,
          source: resp.conversation.source,
          via: resp.via,
          relPath: result.relPath,
          messages: resp.conversation.messages.length,
          extras: result.extras,
          warning: resp.warning,
          trigger,
        });
      } else if (result.status === "error") {
        failed++;
        await pushLog({ ok: false, title: resp.conversation.title, source: resp.conversation.source, error: result.error, trigger });
      }
    } catch (e) {
      failed++;
      await pushLog({ ok: false, error: String((e && e.message) || e), trigger });
    }
  }

  let memory = null;
  if (catalogChanged) {
    memory = await refreshMemoryViews();
    if (!memory.ok) {
      failed++;
      await pushLog({ ok: false, title: "Memory Home update failed", error: memory.error, trigger });
    }
  }

  if (saved) {
    chrome.action.setBadgeText({ text: String(saved) });
    chrome.action.setBadgeBackgroundColor({ color: "#2b6cb0" });
    setTimeout(() => chrome.action.setBadgeText({ text: "" }), 8000);
  }
  return { scanned: tabs.length, saved, failed, memory };
}

function createBackfillState(source) {
  return {
    source,
    saved: 0,
    unchanged: 0,
    processed: 0,
    total: null,
    projectsSaved: 0,
    catalogChanged: false,
    failures: [],
    startedAt: Date.now(),
  };
}

async function reportBackfillProgress(state, active = true, extra = {}) {
  return setBackfillProgress({
    active,
    provider: state.source,
    processed: state.processed,
    total: state.total,
    saved: state.saved,
    unchanged: state.unchanged,
    failed: state.failures.length,
    projectsSaved: state.projectsSaved,
    startedAt: state.startedAt,
    ...extra,
  });
}

async function applyBackfillBatch(resp, settings, state) {
  const captureFailures = (resp.failures || []).map((failure) => ({
    title: failure.title || failure.id || "Untitled",
    error: failure.error || "Capture failed",
  }));
  state.failures.push(...captureFailures);

  for (const conv of resp.conversations || []) {
    try {
      conv.captureMethod = conv.captureMethod || "api";
      conv.captureScope = conv.captureScope || "full";
      const r = await syncConversation(conv, settings);
      state.catalogChanged = state.catalogChanged || r.catalogChanged === true;
      if (r.status === "saved") state.saved++;
      else if (r.status === "unchanged") state.unchanged++;
      else if (r.status === "error") state.failures.push({ title: conv.title || "Untitled", error: r.error });
    } catch (e) {
      state.failures.push({ title: conv.title || "Untitled", error: String((e && e.message) || e) });
    }
  }

  state.processed += Number.isFinite(resp.examined)
    ? resp.examined
    : (resp.conversations || []).length + captureFailures.length;
}

async function finishBackfill(state) {
  let memory = null;
  if (state.catalogChanged) {
    memory = await refreshMemoryViews();
    if (!memory.ok) state.failures.push({ title: "Memory Home", error: memory.error });
  }

  await pushLog({
    ok: state.failures.length === 0,
    title: `Backfill — ${state.saved} saved, ${state.unchanged} unchanged, ${state.failures.length} failed, ${state.projectsSaved} projects`,
    trigger: "backfill",
  });

  const result = {
    ok: state.failures.length === 0,
    saved: state.saved,
    unchanged: state.unchanged,
    failed: state.failures.length,
    failures: state.failures.slice(0, 10),
    projectsSaved: state.projectsSaved,
    processed: state.processed,
    total: state.total == null ? state.processed : state.total,
    memory,
  };
  await reportBackfillProgress(state, false, { completedAt: Date.now() });
  return result;
}

async function backfillChatgptPages(tabId, settings, maxItems, state) {
  let offset = 0;
  const batchSize = 50;

  while (true) {
    if (!(await Licence.canSync())) {
      state.failures.push({ title: "History backup", error: "TRIAL_ENDED" });
      break;
    }
    const remaining = maxItems > 0 ? maxItems - state.processed : batchSize;
    if (maxItems > 0 && remaining <= 0) break;
    const pageLimit = Math.min(batchSize, remaining);
    const resp = await ask(tabId, {
      type: "CHAT_SYNC_EXTRACT_PAGE",
      offset,
      limit: pageLimit,
    });

    if (!resp.ok) {
      state.failures.push({
        title: `ChatGPT history page at offset ${offset}`,
        error: resp.error || "History page failed",
      });
      break;
    }

    if (Number.isFinite(resp.total)) {
      state.total = maxItems > 0 ? Math.min(resp.total, maxItems) : resp.total;
    }
    await applyBackfillBatch(resp, settings, state);
    await reportBackfillProgress(state);

    const nextOffset = Number(resp.nextOffset);
    if (resp.done || !Number.isFinite(nextOffset) || nextOffset <= offset) break;
    offset = nextOffset;
  }

  return finishBackfill(state);
}

// Full history backfill for one provider, driven from an open tab on that site.
// ChatGPT is processed page-by-page so its first 100 items are no longer a hidden cap.
async function backfill(tabId, limit) {
  if (!(await Licence.canSync())) {
    return { ok: false, error: "TRIAL_ENDED" };
  }
  const recent = await chrome.storage.local.get(["backfillProgress"]);
  if (recent.backfillProgress && recent.backfillProgress.active &&
      Date.now() - (recent.backfillProgress.updatedAt || 0) < 15 * 60 * 1000) {
    return { ok: false, error: "BACKFILL_ALREADY_RUNNING" };
  }

  const settings = await getSettings();
  const ping = await ask(tabId, { type: "CHAT_SYNC_PING" });
  if (!ping.ok) return { ok: false, error: ping.error };

  const state = createBackfillState(ping.source || "unknown");
  await reportBackfillProgress(state);

  if (state.source === "chatgpt") {
    return backfillChatgptPages(tabId, settings, Math.max(0, Number(limit) || 0), state);
  }

  const resp = await ask(tabId, { type: "CHAT_SYNC_EXTRACT_ALL", limit: limit || 200 });
  if (!resp.ok) {
    await reportBackfillProgress(state, false, { error: resp.error || "Backfill failed" });
    return { ok: false, error: resp.error };
  }

  if (Number.isFinite(resp.total)) state.total = resp.total;
  await applyBackfillBatch(resp, settings, state);
  await reportBackfillProgress(state);

  if (settings.saveProjects) {
    try {
      const projectResult = await syncProjects(resp.projects);
      state.projectsSaved = projectResult.saved;
      state.failures.push(...projectResult.failures);
    } catch (e) {
      state.failures.push({ title: "Claude projects", error: String((e && e.message) || e) });
    }
  }
  return finishBackfill(state);
}

// ---------- alarms ----------

async function rescheduleAlarm() {
  const { backgroundSync, intervalMinutes } = await getSettings();
  await chrome.alarms.clear(ALARM);
  if (!backgroundSync) return;
  if (!(await Licence.canSync())) {
    await chrome.storage.local.set({ backgroundSync: false });
    return;
  }
  chrome.alarms.create(ALARM, { periodInMinutes: intervalMinutes });
}

chrome.alarms.onAlarm.addListener(async (a) => {
  if (a.name !== ALARM) return;
  const { backgroundSync } = await getSettings();
  if (!backgroundSync) return;
  if (!(await Licence.canSync())) {
    await chrome.storage.local.set({ backgroundSync: false });
    await chrome.alarms.clear(ALARM);
    return;
  }
  await syncOpenTabs("background");
});

chrome.runtime.onInstalled.addListener(async () => {
  const r = await chrome.storage.local.get(["syncedIds", "backgroundSync", "installedAt", "memoryCatalog"]);
  if (!r.installedAt) await chrome.storage.local.set({ installedAt: Date.now() });
  if (!r.syncedIds) await chrome.storage.local.set({ syncedIds: {} });
  if (!r.memoryCatalog) await chrome.storage.local.set({ memoryCatalog: {} });
  if (r.backgroundSync === undefined) await chrome.storage.local.set({ backgroundSync: false });
  await getMemoryCatalog();
  await rescheduleAlarm();
});

chrome.runtime.onStartup.addListener(rescheduleAlarm);

// ---------- popup messages ----------

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.target === "offscreen") return;

  if (msg.type === "SYNC_ACTIVE_TAB") {
    (async () => {
      try {
        if (!(await Licence.canSync())) {
          return sendResponse({ ok: true, status: "error", error: "TRIAL_ENDED" });
        }
        const settings = await getSettings();
        const resp = await ask(msg.tabId, { type: "CHAT_SYNC_EXTRACT" });
        if (!resp.ok) return sendResponse({ ok: false, error: resp.error });
        resp.conversation.captureMethod = resp.via || resp.conversation.captureMethod || "unknown";
        resp.conversation.captureScope = resp.via === "api" ? "full" : "visible";
        const result = await syncConversation(resp.conversation, settings);
        let memory = null;
        if (result.catalogChanged) memory = await refreshMemoryViews();
        // Only record real writes and failures. Logging every "already up to date"
        // click floods the list with duplicates of the same conversation.
        if (result.status !== "unchanged") {
          await pushLog({
            ok: result.status !== "error",
            title: resp.conversation.title,
            source: resp.conversation.source,
            via: resp.via,
            relPath: result.relPath,
            error: result.error,
            messages: resp.conversation.messages.length,
            extras: result.extras,
            warning: resp.warning,
            trigger: "manual",
          });
        }
        sendResponse({
          ok: true,
          via: resp.via,
          warning: resp.warning,
          memory,
          ...result,
          title: resp.conversation.title,
        });
      } catch (e) {
        const error = String((e && e.message) || e);
        await pushLog({ ok: false, title: "Manual sync failed", error, trigger: "manual" });
        sendResponse({ ok: false, error });
      }
    })();
    return true;
  }

  if (msg.type === "BACKFILL") {
    backfill(msg.tabId, msg.limit).then(sendResponse).catch((e) => {
      sendResponse({ ok: false, error: String((e && e.message) || e) });
    });
    return true;
  }

  if (msg.type === "DIAGNOSE") {
    (async () => {
      const resp = await ask(msg.tabId, { type: "CHAT_SYNC_DIAGNOSE" });
      let folder = { hasFolder: false };
      try {
        await ensureOffscreen();
        const f = await chrome.runtime.sendMessage({ target: "offscreen", type: "OFFSCREEN_CHECK_FOLDER" });
        if (f && f.ok) folder = f;
      } catch (e) {}
      sendResponse({ ...resp, folder });
    })();
    return true;
  }




  if (msg.type === "LICENCE_STATE") {
    getLicenceState().then(sendResponse);
    return true;
  }

  if (msg.type === "LICENCE_ACTIVATE") {
    saveLicence(msg.key).then(sendResponse);
    return true;
  }

  if (msg.type === "LICENCE_CLEAR") {
    clearLicence().then(() => sendResponse({ ok: true }));
    return true;
  }

  if (msg.type === "INDEX_VAULT") {
    (async () => {
      try {
        await ensureOffscreen();
        const resp = await chrome.runtime.sendMessage({
          target: "offscreen", type: "OFFSCREEN_SCAN_VAULT", segments: BASE,
        });
        if (!resp || !resp.ok) return sendResponse({ ok: false, error: resp ? resp.error : "no response" });

        const catalog = await getMemoryCatalog();
        let added = 0;
        for (const note of resp.notes || []) {
          if (catalog[note.id]) continue;      // already known — never overwrite fresher data
          catalog[note.id] = { ...note, syncedAt: Date.now(), captureMethod: "indexed", captureScope: "existing" };
          added++;
        }
        await chrome.storage.local.set({ memoryCatalog: catalog });
        const memory = added ? await refreshMemoryViews() : null;
        await pushLog({ ok: true, title: `Indexed ${added} existing note(s) from the vault`, trigger: "index" });
        sendResponse({ ok: true, scanned: (resp.notes || []).length, added, memory });
      } catch (e) {
        sendResponse({ ok: false, error: String((e && e.message) || e) });
      }
    })();
    return true;
  }

  if (msg.type === "SET_SETTINGS") {
    (async () => {
      if (msg.settings && msg.settings.backgroundSync === true && !(await Licence.canSync())) {
        await chrome.storage.local.set({ backgroundSync: false });
        await chrome.alarms.clear(ALARM);
        return sendResponse({ ok: false, error: "TRIAL_ENDED" });
      }
      await chrome.storage.local.set(msg.settings);
      await rescheduleAlarm();
      sendResponse({ ok: true });
    })();
    return true;
  }

  if (msg.type === "REFRESH_MEMORY_VIEWS") {
    refreshMemoryViews().then(sendResponse);
    return true;
  }

  if (msg.type === "GET_STATE") {
    (async () => {
      const settings = await getSettings();
      const licence = await Licence.status();
      if (!licence.licensed && licence.expired && settings.backgroundSync) {
        settings.backgroundSync = false;
        await chrome.storage.local.set({ backgroundSync: false });
        await chrome.alarms.clear(ALARM);
      }
      const catalog = await getMemoryCatalog();
      const r = await chrome.storage.local.get(["log", "memoryStats", "memoryViewsReadyAt", "backfillProgress"]);
      let folder = { hasFolder: false, name: null };
      try {
        await ensureOffscreen();
        const f = await chrome.runtime.sendMessage({ target: "offscreen", type: "OFFSCREEN_CHECK_FOLDER" });
        if (f && f.ok) folder = f;
      } catch (e) {}
      sendResponse({
        settings,
        folder,
        licence,
        log: r.log || [],
        totalSynced: Object.keys(catalog).length,
        memory: r.memoryStats || { conversations: Object.keys(catalog).length, topics: 0 },
        memoryViewsReadyAt: r.memoryViewsReadyAt || null,
        backfillProgress: r.backfillProgress || null,
      });
    })();
    return true;
  }
});

// Shared content-script wiring. Each provider file defines:
//   extractCurrent()  -> conversation for the current page (DOM path)
//   apiCurrent?()     -> Promise<conversation> via the site's own API (preferred)
//   apiPage?()        -> Promise<{conversations,failures,total,nextOffset,done}> paged history
//   apiAll?()         -> Promise<{conversations,projects,total}> one-response history
//   diagnose?()       -> Promise<[{step, ok, detail}]> endpoint health probe
//   isConversationPage?() -> whether current-page capture is expected here
// and calls wireExtractor(source, handlers).

function wireExtractor(source, handlers) {
  // These files are also injected on demand for tabs that predate the install, so
  // guard against double-registering listeners (which would send duplicate replies).
  if (window.__chatSyncWired) return;
  window.__chatSyncWired = source;

  chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
    if (msg.type === "CHAT_SYNC_PING") { sendResponse({ ok: true, source }); return; }
    if (msg.type === "CHAT_SYNC_EXTRACT") {
      (async () => {
        let apiWarning = "";
        if (handlers.apiCurrent) {
          try {
            const conv = await handlers.apiCurrent();
            if (conv && conv.messages.length) {
              sendResponse({ ok: true, conversation: conv, via: "api" });
              return;
            }
          } catch (e) {
            apiWarning = `Full capture was unavailable (${String((e && e.message) || e)}). Saved the visible page only.`;
          }
        }
        try {
          const conv = handlers.extractCurrent();
          if (!conv) {
            sendResponse({ ok: false, error: "No conversation found on this page." });
            return;
          }
          sendResponse({
            ok: true,
            via: "dom",
            warning: apiWarning || "This provider currently supports visible-page capture only.",
            conversation: { artifacts: [], files: [], ...conv, source, url: location.href },
          });
        } catch (e) {
          sendResponse({ ok: false, error: String((e && e.message) || e) });
        }
      })();
      return true;
    }

    if (msg.type === "CHAT_SYNC_EXTRACT_ALL") {
      (async () => {
        if (!handlers.apiAll) {
          sendResponse({ ok: false, error: "Full history not supported for " + source });
          return;
        }
        try {
          sendResponse({ ok: true, ...(await handlers.apiAll(msg.limit || 200)) });
        } catch (e) {
          sendResponse({ ok: false, error: String((e && e.message) || e) });
        }
      })();
      return true;
    }

    if (msg.type === "CHAT_SYNC_EXTRACT_PAGE") {
      (async () => {
        if (!handlers.apiPage) {
          sendResponse({ ok: false, error: "Paged history not supported for " + source });
          return;
        }
        try {
          sendResponse({
            ok: true,
            ...(await handlers.apiPage(msg.offset || 0, msg.limit || 50)),
          });
        } catch (e) {
          sendResponse({ ok: false, error: String((e && e.message) || e) });
        }
      })();
      return true;
    }

    if (msg.type === "CHAT_SYNC_DIAGNOSE") {
      (async () => {
        const steps = [];
        // A provider home/New Chat route has no current conversation by design.
        // Report that as skipped so healthy history API checks are not presented as
        // a failed diagnostic.
        try {
          const expectsConversation = handlers.isConversationPage ? handlers.isConversationPage() : true;
          if (!expectsConversation) {
            steps.push({
              step: "Current-page capture",
              ok: true,
              skipped: true,
              detail: "not applicable — no conversation is open; use Back up all for history",
            });
          } else {
            const conv = handlers.extractCurrent();
            steps.push({
              step: "Current-page capture",
              ok: !!(conv && conv.messages.length),
              detail: conv ? `${conv.messages.length} messages, title "${conv.title}"` : "no readable conversation found",
            });
          }
        } catch (e) {
          steps.push({ step: "Current-page capture", ok: false, detail: String((e && e.message) || e) });
        }

        if (handlers.diagnose) {
          try {
            for (const s of await handlers.diagnose()) steps.push(s);
          } catch (e) {
            steps.push({ step: "API probe", ok: false, detail: String((e && e.message) || e) });
          }
        } else {
          steps.push({ step: "API", ok: false, detail: "not implemented for " + source + " (DOM only)" });
        }
        sendResponse({ ok: true, source, url: location.href, steps });
      })();
      return true;
    }
  });
}

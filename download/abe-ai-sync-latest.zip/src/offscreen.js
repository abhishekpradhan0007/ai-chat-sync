// Offscreen document: the only context that can hold a File System Access handle
// and still be driven by the service worker. Chrome persists FSA grants for
// extension origins, so no user gesture is needed after the initial folder pick.

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.target !== "offscreen") return;

  if (msg.type === "OFFSCREEN_WRITE_BATCH") {
    (async () => {
      try {
        const root = await window.ChatSyncFS.getVaultRoot();
        if (!root) {
          sendResponse({ ok: false, error: "NO_FOLDER" });
          return;
        }
        const written = [];
        for (const f of msg.files) {
          const rel = await window.ChatSyncFS.writeFileAt(root, f.segments, f.filename, f.contents);
          written.push(rel);
        }
        sendResponse({ ok: true, written });
      } catch (e) {
        sendResponse({ ok: false, error: String((e && e.message) || e) });
      }
    })();
    return true;
  }

  if (msg.type === "OFFSCREEN_DELETE_BATCH") {
    (async () => {
      try {
        const root = await window.ChatSyncFS.getVaultRoot();
        if (!root) {
          sendResponse({ ok: false, error: "NO_FOLDER" });
          return;
        }
        const removed = [];
        for (const f of msg.files || []) {
          const didRemove = await window.ChatSyncFS.removeFileAt(root, f.segments, f.filename);
          if (didRemove) removed.push(f.segments.concat(f.filename).join("/"));
        }
        sendResponse({ ok: true, removed });
      } catch (e) {
        sendResponse({ ok: false, error: String((e && e.message) || e) });
      }
    })();
    return true;
  }

  if (msg.type === "OFFSCREEN_SCAN_VAULT") {
    (async () => {
      try {
        const root = await window.ChatSyncFS.getVaultRoot();
        if (!root) return sendResponse({ ok: false, error: "NO_FOLDER" });
        const notes = await window.ChatSyncFS.scanConversationNotes(root, msg.segments);
        sendResponse({ ok: true, notes });
      } catch (e) {
        sendResponse({ ok: false, error: String((e && e.message) || e) });
      }
    })();
    return true;
  }

  if (msg.type === "OFFSCREEN_CHECK_FOLDER") {
    (async () => {
      try {
        const root = await window.ChatSyncFS.getVaultRoot();
        sendResponse({ ok: true, hasFolder: !!root, name: root ? root.name : null });
      } catch (e) {
        sendResponse({ ok: false, error: String((e && e.message) || e) });
      }
    })();
    return true;
  }
});

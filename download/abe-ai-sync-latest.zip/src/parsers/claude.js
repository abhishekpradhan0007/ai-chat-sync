function extractCurrent() {
  const m = location.pathname.match(/\/chat\/([a-f0-9-]+)/i);
  if (!m) return null;

  const titleEl = document.querySelector('[data-testid="chat-menu-trigger"]');
  const title = (titleEl?.textContent || document.title || "Untitled")
    .replace(/\s*[|\-–]\s*Claude.*$/i, "")
    .trim();

  const nodes = Array.from(
    document.querySelectorAll('[data-testid="user-message"], div.font-claude-message')
  );
  const messages = [];
  for (const el of nodes) {
    const text = el.innerText.trim();
    if (!text) continue;
    messages.push({ role: el.matches('[data-testid="user-message"]') ? "user" : "assistant", text });
  }
  if (!messages.length) return null;

  const now = new Date().toISOString();
  return { id: m[1], title, createdISO: now, updatedISO: now, messages };
}

async function apiCurrent() {
  const m = location.pathname.match(/\/chat\/([a-f0-9-]+)/i);
  if (!m) return null;
  const orgId = await ClaudeAPI.getOrgId();
  const raw = await ClaudeAPI.getConversation(orgId, m[1]);
  return ClaudeAPI.normalizeConversation(raw);
}

async function apiAll(limit) {
  const orgId = await ClaudeAPI.getOrgId();
  const list = await ClaudeAPI.listConversations(orgId);
  const slice = list.slice(0, limit);

  const conversations = [];
  const failures = [];
  for (const item of slice) {
    try {
      const raw = await ClaudeAPI.getConversation(orgId, item.uuid);
      conversations.push(ClaudeAPI.normalizeConversation(raw));
    } catch (e) {
      failures.push({
        id: item.uuid,
        title: item.name || item.title || "Untitled Claude conversation",
        error: String((e && e.message) || e),
      });
    }
    await new Promise((r) => setTimeout(r, 250)); // be gentle
  }

  // Projects: instructions + docs
  let projects = [];
  try {
    const rawProjects = await ClaudeAPI.listProjects(orgId);
    for (const p of rawProjects) {
      let docs = [];
      try {
        docs = await ClaudeAPI.getProjectDocs(orgId, p.uuid);
      } catch (e) {
        failures.push({
          id: `project-docs:${p.uuid}`,
          title: `${p.name || "Untitled project"} documents`,
          error: String((e && e.message) || e),
        });
      }
      // Instructions only come back from the per-project detail endpoint.
      let detail = p;
      try {
        detail = await ClaudeAPI.getProject(orgId, p.uuid);
      } catch (e) {
        failures.push({
          id: `project-detail:${p.uuid}`,
          title: `${p.name || "Untitled project"} details`,
          error: String((e && e.message) || e),
        });
      }
      projects.push({
        id: p.uuid,
        name: p.name || "Untitled project",
        description: detail.description || p.description || "",
        instructions: detail.prompt_template || "",
        createdISO: p.created_at || new Date().toISOString(),
        docs: (docs || []).map((d) => ({
          name: d.filename || d.file_name || `${d.uuid}.md`,
          content: d.content || "",
        })),
      });
    }
  } catch (e) {
    failures.push({
      id: "claude-projects",
      title: "Claude projects",
      error: String((e && e.message) || e),
    });
  }

  return { conversations, projects, failures, total: list.length };
}

wireExtractor("claude", { extractCurrent, apiCurrent, apiAll, diagnose });

async function diagnose() {
  const steps = [];
  let orgId = null;
  try {
    orgId = await ClaudeAPI.getOrgId();
    steps.push({ step: "GET /api/organizations", ok: true, detail: `org ${orgId.slice(0, 8)}…` });
  } catch (e) {
    steps.push({ step: "GET /api/organizations", ok: false, detail: String(e.message) });
    return steps;
  }

  let list = null;
  try {
    list = await ClaudeAPI.listConversations(orgId);
    steps.push({
      step: "GET chat_conversations",
      ok: Array.isArray(list),
      detail: Array.isArray(list) ? `${list.length} conversations; keys: ${Object.keys(list[0] || {}).slice(0, 6).join(", ")}` : "not an array",
    });
  } catch (e) {
    steps.push({ step: "GET chat_conversations", ok: false, detail: String(e.message) });
  }

  const probeId = (location.pathname.match(/\/chat\/([a-f0-9-]+)/i) || [])[1] || (list && list[0] && list[0].uuid);
  if (probeId) {
    try {
      const raw = await ClaudeAPI.getConversation(orgId, probeId);
      const conv = ClaudeAPI.normalizeConversation(raw);
      steps.push({
        step: "GET conversation detail",
        ok: conv.messages.length > 0,
        detail: `${conv.messages.length} msgs, ${conv.artifacts.length} artifacts, ${conv.files.length} files, created ${String(conv.createdISO).slice(0, 10)}`,
      });
    } catch (e) {
      steps.push({ step: "GET conversation detail", ok: false, detail: String(e.message) });
    }
  }

  try {
    const projects = await ClaudeAPI.listProjects(orgId);
    steps.push({
      step: "GET projects",
      ok: Array.isArray(projects),
      detail: Array.isArray(projects) ? `${projects.length} projects` : "not an array",
    });
  } catch (e) {
    steps.push({ step: "GET projects", ok: false, detail: String(e.message) });
  }
  return steps;
}

// Perplexity: DOM capture. Threads render as alternating query/answer blocks.
// Sources are captured as a citation list under each answer.

// Verified against a live thread 2026-09-01: Perplexity renders citations behind
// JS rather than as anchors — a real answer contained zero <a href> elements. This
// still runs in case links are present (older threads, shared pages), but source
// capture must not be advertised as working.
function collectSources(answerEl) {
  const links = Array.from(answerEl.querySelectorAll('a[href^="http"]'));
  const seen = new Set();
  const out = [];
  for (const a of links) {
    const href = a.href;
    if (seen.has(href)) continue;
    if (href.includes("perplexity.ai")) continue;
    seen.add(href);
    const label = (a.innerText || "").trim().replace(/\s+/g, " ").slice(0, 80);
    out.push(`- [${label || new URL(href).hostname}](${href})`);
  }
  return out;
}

function extractCurrent() {
  const m = location.pathname.match(/\/search\/([^/?#]+)/) || location.pathname.match(/\/page\/([^/?#]+)/);
  const id = m ? m[1] : location.pathname.replace(/\//g, "-").replace(/^-+/, "") || `perplexity-${Date.now()}`;
  const title = (document.title || "Untitled").replace(/\s*[|\-–]\s*Perplexity.*$/i, "").trim();

  const messages = [];

  // Queries: Perplexity marks user turns with a heading-like block.
  const queryNodes = Array.from(
    document.querySelectorAll('[class*="whitespace-pre-line"], h1.group\\/query, div[class*="query"]')
  );
  const answerNodes = Array.from(
    document.querySelectorAll('[id^="markdown-content"], div[class*="prose"]')
  );

  const max = Math.max(queryNodes.length, answerNodes.length);
  for (let i = 0; i < max; i++) {
    const q = queryNodes[i] && (typeof domToMarkdown === "function"
      ? domToMarkdown(queryNodes[i]) : queryNodes[i].innerText).trim();
    if (q) messages.push({ role: "user", text: q });

    const a = answerNodes[i];
    if (a) {
      const text = (typeof domToMarkdown === "function" ? domToMarkdown(a) : a.innerText).trim();
      if (text) {
        const sources = collectSources(a);
        messages.push({
          role: "assistant",
          text: sources.length ? `${text}\n\n### Sources\n${sources.join("\n")}` : text,
        });
      }
    }
  }

  if (!messages.length) return null;
  const now = new Date().toISOString();
  return { id, title, createdISO: now, updatedISO: now, messages };
}

async function diagnose() {
  const steps = [];
  const onThread = /\/search\//.test(location.pathname);
  steps.push({ step: "On a Perplexity thread", ok: onThread,
    detail: onThread ? location.pathname : "open a thread — the home page has nothing to capture" });

  const answers = document.querySelectorAll('[id^="markdown-content"], div[class*="prose"]').length;
  steps.push({ step: "Answer blocks found", ok: answers > 0, detail: `${answers} found` });

  const code = document.querySelectorAll("pre code").length;
  steps.push({ step: "Code blocks", ok: true,
    detail: `${code} found — captured as fences, but Perplexity sets no language class so fences are untagged` });

  const links = [...document.querySelectorAll('a[href^="http"]')]
    .filter((a) => !a.href.includes("perplexity.ai")).length;
  steps.push({ step: "Source citations", ok: true,
    detail: links ? `${links} link(s) captured` : "none exposed as links — Perplexity renders citations via JS, so sources are not captured" });

  return steps;
}

wireExtractor("perplexity", { extractCurrent, diagnose });

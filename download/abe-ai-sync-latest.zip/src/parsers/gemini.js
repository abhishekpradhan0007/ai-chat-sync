// Gemini has no public REST API — Angular app, DOM capture only.
// Verified against a live signed-in account 2026-08-22: <user-query> and
// <model-response> are present and correctly ordered (10/10 turns extracted).
// Their innerText carries screen-reader prefixes ("You said", "Gemini said")
// which must be stripped or they end up in every saved file.

function stripA11yPrefix(text, isUser) {
  const label = isUser ? /^You said\s*/i : /^Gemini said\s*/i;
  return text.replace(label, "").trim();
}

function geminiTurns() {
  let turns = Array.from(document.querySelectorAll("user-query, model-response"));
  if (!turns.length) {
    turns = Array.from(document.querySelectorAll(".query-text, .model-response-text, .response-content"));
  }
  return turns;
}

function extractCurrent() {
  const m = location.pathname.match(/\/app\/([a-z0-9]+)/i);
  const id = m ? m[1] : location.pathname.replace(/\//g, "-").replace(/^-+/, "") || `gemini-${Date.now()}`;
  const title = (document.title || "Untitled")
    .replace(/\s*[-–|]\s*Google Gemini\s*$/i, "")
    .replace(/\s*[-–|]\s*Gemini\s*$/i, "")
    .trim();

  const messages = [];
  for (const el of geminiTurns()) {
    const tag = el.tagName.toLowerCase();
    const isUser = tag === "user-query" || el.classList.contains("query-text");
    // Markdown, not innerText: preserves code fences, languages and LaTeX.
    const raw = typeof domToMarkdown === "function"
      ? domToMarkdown(el)
      : (el.innerText || "").trim();
    const text = stripA11yPrefix(raw, isUser);
    if (text) messages.push({ role: isUser ? "user" : "assistant", text });
  }

  if (!messages.length) return null;
  const now = new Date().toISOString();
  return { id, title, createdISO: now, updatedISO: now, messages };
}

async function diagnose() {
  const steps = [];
  const signedIn = !/accounts\.google\.com|ServiceLogin/.test(location.href);
  steps.push({ step: "Signed in to Gemini", ok: signedIn, detail: signedIn ? "yes" : "sign in at gemini.google.com" });

  const onConversation = /\/app\/[a-z0-9]+/i.test(location.pathname);
  steps.push({
    step: "On a conversation page",
    ok: onConversation,
    detail: onConversation ? location.pathname : "open a chat from Recents — /app alone is a blank new chat",
  });

  const uq = document.querySelectorAll("user-query").length;
  const mr = document.querySelectorAll("model-response").length;
  steps.push({
    step: "DOM selectors",
    ok: uq > 0 || mr > 0,
    detail: `${uq} user-query, ${mr} model-response`,
  });

  steps.push({
    step: "Note",
    ok: true,
    detail: "Gemini has no API — only the open conversation can be captured, not full history.",
  });
  return steps;
}

wireExtractor("gemini", { extractCurrent, diagnose });

function extractCurrent() {
  // Without /c/<id> there is no conversation on this page. Falling back to the
  // pathname gave every such page the id "/", so unrelated chats collided under
  // one entry and overwrote each other.
  const m = location.pathname.match(/\/c\/([a-f0-9-]+)/i);
  if (!m) return null;
  const id = m[1];
  const title = (document.title || "Untitled").replace(/\s*[|\-–]\s*Grok.*$/i, "").trim();

  let nodes = Array.from(document.querySelectorAll('[class*="message-bubble"], [data-testid*="message"]'));
  if (!nodes.length) {
    nodes = Array.from(document.querySelectorAll("main div[class*='items-end'], main div[class*='items-start']"));
  }
  const messages = nodes
    .map((el) => {
      const text = el.innerText.trim();
      if (!text) return null;
      const isUser = /items-end/.test(el.className) || el.closest('[data-testid*="user"]');
      return { role: isUser ? "user" : "assistant", text };
    })
    .filter(Boolean);

  if (!messages.length) return null;
  const now = new Date().toISOString();
  return { id, title, createdISO: now, updatedISO: now, messages };
}

async function apiCurrent() {
  const m = location.pathname.match(/\/c\/([a-f0-9-]+)/i);
  if (!m) return null;
  const convId = m[1];
  const list = await GrokAPI.listConversations(200);
  const meta = list.find((c) => c.conversationId === convId) || { conversationId: convId, title: document.title };
  const responses = await GrokAPI.getResponses(convId);
  return GrokAPI.normalizeConversation(meta, responses);
}

async function apiAll(limit) {
  const list = await GrokAPI.listConversations(Math.min(limit, 200));
  const conversations = [];
  const failures = [];
  for (const meta of list.slice(0, limit)) {
    try {
      const responses = await GrokAPI.getResponses(meta.conversationId);
      const conv = GrokAPI.normalizeConversation(meta, responses);
      if (conv.messages.length) conversations.push(conv);
      else failures.push({
        id: meta.conversationId,
        title: meta.title || "Untitled Grok conversation",
        error: "Conversation contained no readable messages.",
      });
    } catch (e) {
      failures.push({
        id: meta.conversationId,
        title: meta.title || "Untitled Grok conversation",
        error: String((e && e.message) || e),
      });
    }
    await new Promise((r) => setTimeout(r, 250));
  }
  return { conversations, projects: [], failures, total: list.length };
}

async function diagnose() {
  const steps = [];
  let list = null;
  try {
    list = await GrokAPI.listConversations(5);
    steps.push({
      step: "GET /rest/app-chat/conversations",
      ok: Array.isArray(list),
      detail: `${list.length} conversations; keys: ${Object.keys(list[0] || {}).slice(0, 5).join(", ")}`,
    });
  } catch (e) {
    steps.push({ step: "GET /rest/app-chat/conversations", ok: false, detail: String(e.message) });
    return steps;
  }

  const probe = (location.pathname.match(/\/c\/([a-f0-9-]+)/i) || [])[1] || (list[0] && list[0].conversationId);
  if (probe) {
    try {
      const responses = await GrokAPI.getResponses(probe);
      const meta = list.find((c) => c.conversationId === probe) || { conversationId: probe };
      const conv = GrokAPI.normalizeConversation(meta, responses);
      steps.push({
        step: "response-node + load-responses",
        ok: conv.messages.length > 0,
        detail: `${conv.messages.length} msgs, ${conv.files.length} files, created ${String(conv.createdISO).slice(0, 10)}`,
      });
    } catch (e) {
      steps.push({ step: "response-node + load-responses", ok: false, detail: String(e.message) });
    }
  }
  return steps;
}

wireExtractor("grok", { extractCurrent, apiCurrent, apiAll, diagnose });

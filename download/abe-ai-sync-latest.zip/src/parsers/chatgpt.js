function extractCurrent() {
  const m = location.pathname.match(/\/c\/([a-f0-9-]+)/i);
  const id = m ? m[1] : location.pathname;
  const title = (document.title || "Untitled").replace(/\s*[|\-–]\s*ChatGPT.*$/i, "").trim();

  const messages = Array.from(document.querySelectorAll("[data-message-author-role]"))
    .map((el) => {
      const role = el.getAttribute("data-message-author-role") === "user" ? "user" : "assistant";
      const text = el.innerText.trim();
      return text ? { role, text } : null;
    })
    .filter(Boolean);

  if (!messages.length) return null;
  const now = new Date().toISOString();
  return { id, title, createdISO: now, updatedISO: now, messages };
}

function isConversationPage() {
  return /\/c\/[a-f0-9-]+/i.test(location.pathname);
}

async function apiCurrent() {
  const m = location.pathname.match(/\/c\/([a-f0-9-]+)/i);
  if (!m) return null;
  const raw = await ChatgptAPI.getConversation(m[1]);
  return ChatgptAPI.normalizeConversation(raw, m[1]);
}

async function apiPage(offset = 0, limit = 50) {
  const safeOffset = Math.max(0, Number(offset) || 0);
  const safeLimit = Math.min(100, Math.max(1, Number(limit) || 50));
  const page = await ChatgptAPI.listConversationPage(safeLimit, safeOffset);
  const list = page.items || [];
  const conversations = [];
  const failures = [];
  for (const item of list) {
    try {
      const raw = await ChatgptAPI.getConversation(item.id);
      conversations.push(ChatgptAPI.normalizeConversation(raw, item.id));
    } catch (e) {
      failures.push({
        id: item.id,
        title: item.title || "Untitled ChatGPT conversation",
        error: String((e && e.message) || e),
      });
    }
    await new Promise((r) => setTimeout(r, 250));
  }
  const nextOffset = safeOffset + list.length;
  const total = Number.isFinite(page.total) ? page.total : null;
  return {
    conversations,
    projects: [],
    failures,
    total,
    examined: list.length,
    nextOffset,
    done: list.length === 0 || list.length < safeLimit || (total != null && nextOffset >= total),
  };
}

// Compatibility path for callers that still ask for one response. It now walks
// multiple list pages instead of silently truncating at the first 100 chats.
async function apiAll(limit = 200) {
  const target = Math.max(1, Number(limit) || 200);
  const conversations = [];
  const failures = [];
  let offset = 0;
  let total = null;

  while (offset < target) {
    const page = await apiPage(offset, Math.min(50, target - offset));
    conversations.push(...page.conversations);
    failures.push(...page.failures);
    if (page.total != null) total = page.total;
    const previousOffset = offset;
    offset = page.nextOffset;
    if (page.done || offset <= previousOffset) break;
  }

  return { conversations, projects: [], failures, total: total == null ? offset : total };
}

wireExtractor("chatgpt", { extractCurrent, isConversationPage, apiCurrent, apiPage, apiAll, diagnose });

async function diagnose() {
  const steps = [];
  let list = null;
  try {
    list = await ChatgptAPI.listConversations(5);
    steps.push({
      step: "GET /backend-api/conversations",
      ok: Array.isArray(list),
      detail: Array.isArray(list) ? `${list.length} returned; keys: ${Object.keys(list[0] || {}).slice(0, 6).join(", ")}` : "not an array",
    });
  } catch (e) {
    steps.push({ step: "GET /backend-api/conversations", ok: false, detail: String(e.message) });
    return steps;
  }

  const probeId = (location.pathname.match(/\/c\/([a-f0-9-]+)/i) || [])[1] || (list[0] && list[0].id);
  if (probeId) {
    try {
      const raw = await ChatgptAPI.getConversation(probeId);
      const conv = ChatgptAPI.normalizeConversation(raw, probeId);
      steps.push({
        step: "GET conversation detail",
        ok: conv.messages.length > 0,
        detail: `${conv.messages.length} msgs, ${conv.files.length} files, created ${String(conv.createdISO).slice(0, 10)}`,
      });
    } catch (e) {
      steps.push({ step: "GET conversation detail", ok: false, detail: String(e.message) });
    }
  }
  return steps;
}
